# -*- coding: UTF-8 -*-
# @yasinkuyu

# TODO 
class analyze():
    
    def position():
        return 1
    
    @staticmethod
    def direction(ticker):
        
        # Todo: Analyze, best price position
        hight = float(ticker['hight'])
        low = float(ticker['low'])

        return False
