# -*- coding: UTF-8 -*-
# @yasinkuyu

class Messages():
    
    @staticmethod
    def get(msg):
        print ('m: ' + msg)
        exit(1)