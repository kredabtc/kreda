# @yasinkuyu

# Get an Key and Secret 
# https://www.kucoin.com/#/user/setting/api

api_key = ''
api_secret = ''

recv_window = 6000000